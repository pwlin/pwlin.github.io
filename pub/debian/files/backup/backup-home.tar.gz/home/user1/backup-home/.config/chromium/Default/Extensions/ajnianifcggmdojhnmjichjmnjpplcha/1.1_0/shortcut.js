//
// This content script can be loaded for
// file:/// and http:// and some https:// tabs
//
// See these URLs tables:
// http://www.cambiaresearch.com/articles/15/javascript-char-codes-key-codes
// http://www.expandinghead.net/keycode.html
//

//
// check for F9 and send to the extension callback listener
//
function flstFlipKey(e)
{
	//
	// Function keys F1-F12 map to keycodes 112-123 
	// F9 --> 120
	//
	if (e.which == 120)
		chrome.extension.sendRequest({ req: 0 });
} 

window.addEventListener('keyup', flstFlipKey, false);
